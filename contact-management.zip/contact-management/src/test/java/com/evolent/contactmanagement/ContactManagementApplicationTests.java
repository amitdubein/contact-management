package com.evolent.contactmanagement;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactManagementApplicationTests {

	/*@Test
	void contextLoads() {
	}*/

}
