package com.evolent.contactmanagement.controller;


import com.evolent.contactmanagement.entity.ContactEntity;
import com.evolent.contactmanagement.service.ContactService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Arrays;

import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(ContactController.class)
@ActiveProfiles("test")
public class ContactControllerTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private ContactService contactService;
    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @WithMockUser(username = "contact", password = "password123")
    public void getContactByIdTest() throws Exception {

        ContactEntity contactEntity = createContactDetails();
        given(contactService.getContactById(anyLong())).willReturn(contactEntity);
        mockMvc.perform(MockMvcRequestBuilders
                .get("/health-care/user/contact/{id}", 1)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(jsonPath("$.firstName", is(contactEntity.getFirstName())))
                .andExpect(jsonPath("$.lastName", is(contactEntity.getLastName())))
                .andExpect(jsonPath("$.email", is(contactEntity.getEmail())))
                .andExpect(jsonPath("$.status", is(contactEntity.getStatus())))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "contact", password = "password123")
    public void getAllContactsTest() throws Exception {

        ContactEntity contactEntity = createContactDetails();
        given(contactService.getAllContacts()).willReturn(Arrays.asList(contactEntity));
        mockMvc.perform(MockMvcRequestBuilders
                .get("/health-care/user/contact")
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(jsonPath("$[0].firstName", is(contactEntity.getFirstName())))
                .andExpect(jsonPath("$[0].lastName", is(contactEntity.getLastName())))
                .andExpect(jsonPath("$[0].email", is(contactEntity.getEmail())))
                .andExpect(jsonPath("$[0].status", is(contactEntity.getStatus())))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "contact", password = "password123")
    public void createContactTest() throws Exception {

        ContactEntity contactEntity = createContactDetails();
        given(contactService.createOrUpdateContact(any(ContactEntity.class))).willReturn(contactEntity);
        mockMvc.perform(post("/health-care/user/contact")
                .content(objectMapper.writeValueAsString(contactEntity))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.firstName", is(contactEntity.getFirstName())))
                .andExpect(jsonPath("$.lastName", is(contactEntity.getLastName())))
                .andExpect(jsonPath("$.email", is(contactEntity.getEmail())))
                .andExpect(jsonPath("$.status", is(contactEntity.getStatus())))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "contact", password = "password123")
    public void updateContactTest() throws Exception {

        ContactEntity contactEntity = createContactDetails();
        given(contactService.createOrUpdateContact(any(ContactEntity.class))).willReturn(contactEntity);
        mockMvc.perform(put("/health-care/user/contact")
                .content(objectMapper.writeValueAsString(contactEntity))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.firstName", is(contactEntity.getFirstName())))
                .andExpect(jsonPath("$.lastName", is(contactEntity.getLastName())))
                .andExpect(jsonPath("$.email", is(contactEntity.getEmail())))
                .andExpect(jsonPath("$.status", is(contactEntity.getStatus())))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "contact", password = "password123")
    public void deleteContactTest() throws Exception {

        Mockito.doNothing().when(contactService).deleteContact(anyLong());
        mockMvc.perform(MockMvcRequestBuilders
                .delete("/health-care/user/contact/{id}", 1)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk());
    }

    private ContactEntity createContactDetails() {
        ContactEntity contactEntity = new ContactEntity();
        contactEntity.setId(1L);
        contactEntity.setFirstName("Anil");
        contactEntity.setLastName("Dube");
        contactEntity.setPhone(9999999L);
        contactEntity.setStatus("Active");
        return contactEntity;
    }

}
