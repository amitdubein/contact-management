package com.evolent.contactmanagement.service.impl;

import com.evolent.contactmanagement.dao.ContactRepository;
import com.evolent.contactmanagement.entity.ContactEntity;
import com.evolent.contactmanagement.exception.ContactNotFoundException;
import com.evolent.contactmanagement.service.ContactService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class ContactServiceImpl implements ContactService {

	@Autowired
    private ContactRepository repository;

	@Override
	public ContactEntity getContactById(Long id) throws ContactNotFoundException {
		Optional<ContactEntity> contact=repository.findById(id);
		if(contact.isPresent()) {
            return contact.get();
        } else {
            log.error("There was exception, No Contact record exist for given id");
            throw new ContactNotFoundException("No Contact record exist for given id");
        }
	}

    @Override
    public List<ContactEntity> getAllContacts()  {
        return repository.findAll();
    }

    @Override
    public ContactEntity createOrUpdateContact(ContactEntity contactEntity) {
        return repository.save(contactEntity);
    }

    @Override
    public void deleteContact(Long id)  {
        Optional<ContactEntity> contact=repository.findById(id);
        if(contact.isPresent()) {
            repository.deleteById(id);
        } else {
            throw new ContactNotFoundException("No Contact record exist for given id");
        }
    }
}
