/**
 * 
 */
package com.evolent.contactmanagement.entity;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

/**
 * @author Dell
 *
 */
@Getter
@Setter
@Entity
@Table(name = "CONTACT_DETAIL")
public class ContactEntity {
	@Id
	@GeneratedValue
	private Long id;
	@Column(name="FIRST_NAME")
	private String firstName;
	@Column(name="LAST_NAME")
	private String lastName;
	@Column(name="EMAIL_ID")
	private String email;
	@Column(name="PHONE_NUMBER")
	private Long phone;
	@Column(name="USER_STATUS")
	private String status;
}
