package com.evolent.contactmanagement.service.impl;

import com.evolent.contactmanagement.dao.ContactRepository;
import com.evolent.contactmanagement.entity.ContactEntity;
import com.evolent.contactmanagement.exception.ContactNotFoundException;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;

@RunWith(MockitoJUnitRunner.class)
public class ContactServiceImplTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Mock
    private ContactRepository repository;
    @InjectMocks
    private ContactServiceImpl contactService;

    @Test
    public void whenGetContactById_shouldReturnContactEntity() {

        ContactEntity contactEntity = createContactDetails();
        given(repository.findById(anyLong())).willReturn(Optional.of(contactEntity));
        ContactEntity response = contactService.getContactById(1L);
        assertEquals(contactEntity.getId(), response.getId());
        assertEquals(contactEntity.getFirstName(), response.getFirstName());
        assertEquals(contactEntity.getLastName(), response.getLastName());
    }

    @Test
    public void whenGetContactById_shouldReturnContactNotFoundError() {

        given(repository.findById(anyLong())).willReturn(Optional.empty());
        thrown.expect(ContactNotFoundException.class);
        contactService.getContactById(1L);
    }

    @Test
    public void whenGetAllContacts_shouldReturnContactEntityList() {

        ContactEntity contactEntity = createContactDetails();
        given(repository.findAll()).willReturn(Collections.singletonList(contactEntity));
        List<ContactEntity> response = contactService.getAllContacts();
        assertEquals(contactEntity.getId(), response.get(0).getId());
        assertEquals(contactEntity.getFirstName(), response.get(0).getFirstName());
        assertEquals(contactEntity.getLastName(), response.get(0).getLastName());
    }

    @Test
    public void whenCreateContact_shouldReturnContactEntity() {

        ContactEntity contactEntity = createContactDetails();
        given(repository.save(any(ContactEntity.class))).willReturn(contactEntity);
        ContactEntity response = contactService.createOrUpdateContact(contactEntity);
        assertEquals(contactEntity.getId(), response.getId());
        assertEquals(contactEntity.getFirstName(), response.getFirstName());
        assertEquals(contactEntity.getLastName(), response.getLastName());
    }

    @Test
    public void whenDeleteContact_shouldNotReturnError() {

        ContactEntity contactEntity = createContactDetails();
        given(repository.findById(anyLong())).willReturn(Optional.of(contactEntity));
        Mockito.doNothing().when(repository).deleteById(anyLong());
        contactService.deleteContact(1L);
    }

    @Test
    public void whenDeleteContact_shouldReturnContactNotFoundError() {

        given(repository.findById(anyLong())).willReturn(Optional.empty());
        thrown.expect(ContactNotFoundException.class);
        contactService.deleteContact(1L);
    }

    private ContactEntity createContactDetails() {
        ContactEntity contactEntity = new ContactEntity();
        contactEntity.setId(1L);
        contactEntity.setFirstName("Anil");
        contactEntity.setLastName("Dube");
        contactEntity.setPhone(9999999L);
        contactEntity.setStatus("Active");
        return contactEntity;
    }

}
