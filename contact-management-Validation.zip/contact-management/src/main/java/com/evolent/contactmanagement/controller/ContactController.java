package com.evolent.contactmanagement.controller;

import com.evolent.contactmanagement.entity.ContactEntity;
import com.evolent.contactmanagement.service.ContactService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * @author Amitkumar Dube
 */


@RestController
@RequestMapping("/health-care/user/contact")
@Api(value = "Evolent Contact Management Rest APIs")
@Slf4j
public class ContactController {

    @Autowired
    ContactService contactService;

    @ApiOperation(value = "API for Get Contact Details by ID"
            , response = ContactEntity.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Contact Details Successfully sent"),
            @ApiResponse(code = 404, message = "No Contact record exists for given id")})
    @GetMapping(value = "/{id}")
    public ResponseEntity<ContactEntity> getContactById(@PathVariable String id) throws Exception {
        log.info("Request received for getting contact details by id");
        return ResponseEntity.ok(contactService.getContactById(Long.parseLong(id)));
    }

    @ApiOperation(value = "API for Get All Contact Details"
            , response = ContactEntity.class, responseContainer = "List")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Contact Details Successfully sent"),
            @ApiResponse(code = 404, message = "No Contact record exists")})
    @GetMapping
    public ResponseEntity<List<ContactEntity>> getAllContacts() {
        log.info("Request received for getting all contact details");
        return ResponseEntity.ok(contactService.getAllContacts());
    }

    @ApiOperation(value = "API for Create Contact Details"
            , response = ContactEntity.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Contact Details created Successfully")})
    @PostMapping(consumes = "application/json", produces = "application/json")
    public ResponseEntity<ContactEntity> createContact(@Valid @RequestBody ContactEntity contactEntity) {
        log.info("Request received for creating contact details");
        return ResponseEntity.ok(contactService.createOrUpdateContact(contactEntity));
    }

    @ApiOperation(value = "API for Delete Contact Details by ID"
            , response = String.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Deleted Contact Successfully"),
            @ApiResponse(code = 404, message = "No Contact record exists for given id")})
    @DeleteMapping(value = "/{id}")
    public ResponseEntity<String> deleteContact(@PathVariable String id) {
        log.info("Request received for deleting contact details");
        contactService.deleteContact(Long.parseLong(id));
        return ResponseEntity.ok("Deleted Contact Successfully");
    }

    @ApiOperation(value = "API for Update Contact Details"
            , response = ContactEntity.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Updated Contact Successfully")})
    @PutMapping
    public ResponseEntity<ContactEntity> updateContact(@RequestBody ContactEntity contactEntity) {
        log.info("Request received for updating contact details");
        return ResponseEntity.ok(contactService.createOrUpdateContact(contactEntity));
    }
}
