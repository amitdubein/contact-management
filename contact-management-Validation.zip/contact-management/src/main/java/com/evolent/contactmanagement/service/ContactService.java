package com.evolent.contactmanagement.service;

import com.evolent.contactmanagement.entity.ContactEntity;

import java.util.List;

public interface ContactService {

    ContactEntity getContactById(Long id);

    List<ContactEntity> getAllContacts();

    ContactEntity createOrUpdateContact(ContactEntity contactEntity);

    void deleteContact(Long id);
}
