/**
 *
 */
package com.evolent.contactmanagement.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

/**
 * @author Dell
 *
 */
@Getter
@Setter
@Entity
@Table(name = "CONTACT_DETAIL")

public class ContactEntity {
    @Id
    @GeneratedValue
    private Long id;
    @Column(name = "FIRST_NAME")
    @NotEmpty(message = "Please provide a firstName")
    private String firstName;
    @Column(name = "LAST_NAME")
    @NotEmpty(message = "Please provide a lastName")
    private String lastName;
    @Column(name = "EMAIL_ID")
    @Email
    private String email;
    @Column(name = "PHONE_NUMBER")
    @Min(10)
    private Long phone;
    @Column(name = "USER_STATUS")
    @NotEmpty(message = "Please provide a status")
    private String status;
}
